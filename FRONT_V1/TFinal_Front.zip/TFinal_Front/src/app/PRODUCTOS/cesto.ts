export class Cesto {
    idProducto: string;
    descripcion: string;
    imagen: string;
    montototal: number;
    cantidad: number;

}
