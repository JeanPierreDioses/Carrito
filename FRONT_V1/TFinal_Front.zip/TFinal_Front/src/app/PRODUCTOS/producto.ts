export class Producto {
    idProducto: string;
    descripcion: string;
    imagen: string;
    precioUnidad: number;
    stock: number;
}
