import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Ventas } from './ventas';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SventasService {


  private baseURL1 ="http://localhost:8091/api/v1/get_pedidos"

  constructor(private http:HttpClient) { }
  
  CrearPedido(pro:Ventas):Observable<Object>{
   return this.http.post(`${this.baseURL1}`,pro);
   }

}
