export class Usuario {
    idUsuario: number; 
    nombres: string;
    apellidos: string;
    direccion: string;
    fechaNacimiento: Date;
    sexo: string; 
    correo: string;
    password: string;
    tipoUsuario: string;
    
}
